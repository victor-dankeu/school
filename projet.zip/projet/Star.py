#coding:utf-8
import turtle
#Importation de la bibliothèque de dessin turtle

#Affichage de dessin a l'écran à l'aide de la fonction screen()
ws=turtle.Screen()

star= turtle.Turtle()

Nbre= 10
#On demande a l'utilisateur de rentrez un nombre superieur à Zero
Userforward= int(input("please enter forward number superior to Zero ")) 
Userforward=  Userforward *2
#initialisation de la varible i
i=0
#si le nombre entrer par l'utilisateur est positive et superieur à zero alors il va executer le programme
if Nbre > 0 :
    #boucle va nous permettre de dessiner le star  en, fonction de nombre defini de base
    for i in range(Nbre) :
        star.forward(Userforward)
        star.right(144)
else:
        nbre =int('veillez entrez un nombre positive superieur à zéro')


print("bien joué !")


